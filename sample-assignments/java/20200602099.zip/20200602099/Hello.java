public class Hello {
    public static void world() {
        System.out.println("hello world");
    }
}
