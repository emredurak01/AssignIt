#include <stdio.h>
int main() {
   printf("Hello world");
   return 0;
}
