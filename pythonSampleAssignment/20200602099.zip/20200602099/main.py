print('1. append a new student to the file')
print('2. read all students\' data from the file')
print('3. exit')
path = 'students.txt'
s = '\t' # separator
while (True):
    option = input('option: ')
    match option:
        case '1':
            f = open(path, 'a')
            first = input('first name: ')
            last = input('last name: ')
            midterm = input('midterm grade: ')
            final = input('final grade: ')
            f.write(first + s + last + s + midterm + s + final + '\n')
            f.close()
        case '2':
            print('first' + s + 'last' + s + 'midterm' + s + 'final' + s +
                  'grade')
            f = open(path)
            lines = f.readlines()
            grades = []
            for i in lines:
                line = i.split()
                grade = float(line[2]) * .4 + float(line[3]) * .6
                grades.append(grade)
                print(line[0] + s + line[1] + s + line[2] + s + line[3] +
                      s + str(grade))
            maximum = max(grades)
            minimum = min(grades)
            print('max: ' + str(maximum))
            print('min: ' + str(minimum))
            print('min: ' + str((maximum + minimum) / 2))
            f.close()
        case '3':
            break
        case _:
            print('invalid option')
